"use strict";
let counter1 = 0;
let counter2 = 1;

const minCounter = () => {
  counter2++;
};

const numberCounter = () => {
  counter1++;
  const text = document.querySelector(".text");

  if (counter1 < 60) {
    text.innerHTML = `Escrito hace ${counter1} segundos`;
  } else if (counter1 == 60) {
    text.innerHTML = `Escrito hace ${counter2} minutos`;
  }
};

setInterval(numberCounter, 1000);
setInterval(minCounter, 60000);
