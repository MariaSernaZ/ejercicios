"use strict";

const showMessage = () => {
  const windowSession = document.querySelector(".js-window");
  windowSession.classList.remove("hidden");
};

setInterval(showMessage, 15000);
